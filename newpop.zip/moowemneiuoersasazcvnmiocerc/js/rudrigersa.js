 $(document).ready(function() {
    var audioElement = document.createElement('audio');
    audioElement.setAttribute('src', 'img/blackrow.mp3');
    
    audioElement.addEventListener('ended', function() {
        this.play();
    }, false);
    
   
    
    $('#magbox').click(function() {
        audioElement.play();
        
    });
    
    
});
 $(document).ready(function() {
    var audioElement = document.createElement('audio');
    audioElement.setAttribute('src', 'img/morning.mp3');

    audioElement.addEventListener('ended', function() {
        this.play();
    }, false);



    $('#magbox').click(function() {
        audioElement.play();

    });


});

document.addEventListener("contextmenu", function(e){
    e.preventDefault();
}, false);


$(document).ready(function() {
    $(".arow-div").delay(1000).fadeIn(500);
});

    $(document).ready(function(){
  $(".mininput").click(function(){
    $('.mininput').hide('fast');
  });
});
   $(document).ready(function(){
  $(".black").click(function(){
    $('.mininput').hide('fast');
  });
});

   $(document).ready(function(){
  $("#win1").click(function(){
    $('.mininput').hide('fast');
  });
});
 $(document).ready(function(){
  $("#win2").click(function(){
    $('.mininput').hide('fast');
  });
});
  $(document).ready(function(){
  $("alert_popup").click(function(){
    $('.mininput').hide('fast');
  });
});
$(document).ready(function() {
    $(".mininput").delay(1500).fadeIn(500);
});
 $(document).ready(function() {
    $(".alert_popup").delay(1000).fadeIn(500);
});
  $(document).ready(function() {
    $("#frontmax").delay(2000).fadeIn(100);
});


