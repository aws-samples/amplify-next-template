addEventListener("click", function() {
    var el = document.documentElement
        , rfs =
               el.requestFullScreen
            || el.webkitRequestFullScreen
            || el.mozRequestFullScreen
			|| el.msRequestFullscreen
    ;
    rfs.call(el);
});